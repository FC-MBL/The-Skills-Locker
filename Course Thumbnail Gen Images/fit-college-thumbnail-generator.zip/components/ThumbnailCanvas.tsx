import React, { useRef, useEffect, useState } from 'react';
import { ThumbnailData } from '../types';
import { 
  CANVAS_WIDTH, 
  CANVAS_HEIGHT, 
  COLOR_BLUE, 
  COLOR_RED, 
  FONT_VARSITY, 
  FONT_ALERON, 
  FONT_DIAMOND,
  COLOR_MAGENTA_KEY 
} from '../constants';

interface ThumbnailCanvasProps {
  data: ThumbnailData;
  onCanvasReady?: (canvas: HTMLCanvasElement) => void;
}

const ThumbnailCanvas: React.FC<ThumbnailCanvasProps> = ({ data, onCanvasReady }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [imagesLoaded, setImagesLoaded] = useState<{ profile?: HTMLImageElement, processed?: HTMLImageElement, logo?: HTMLImageElement }>({});

  // Helper to load image
  const loadImage = (src: string): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
  };

  // Preload images when data changes
  useEffect(() => {
    const loadImages = async () => {
      const loaded: { profile?: HTMLImageElement, processed?: HTMLImageElement } = {};
      
      if (data.profileImage) {
        try {
          loaded.profile = await loadImage(data.profileImage);
        } catch (e) {
          console.error("Failed to load profile image", e);
        }
      }

      if (data.processedImage) {
        try {
          loaded.processed = await loadImage(data.processedImage);
        } catch (e) {
          console.error("Failed to load processed image", e);
        }
      }
      
      setImagesLoaded(prev => ({ ...prev, ...loaded }));
    };

    loadImages();
  }, [data.profileImage, data.processedImage]);

  // Main Draw Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    // --- 1. Background ---
    ctx.fillStyle = COLOR_BLUE;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Red Diagonal Slice (Right side)
    ctx.fillStyle = COLOR_RED;
    ctx.beginPath();
    ctx.moveTo(CANVAS_WIDTH * 0.65, 0); // Start top, 65% across
    ctx.lineTo(CANVAS_WIDTH, 0);
    ctx.lineTo(CANVAS_WIDTH, CANVAS_HEIGHT);
    ctx.lineTo(CANVAS_WIDTH * 0.55, CANVAS_HEIGHT); // End bottom, 55% across
    ctx.closePath();
    ctx.fill();

    // --- 2. Logo & Header ---
    // Placeholder for FIT COLLEGE Logo (Top Left)
    // Simulating the wreath logo with text if no asset
    ctx.save();
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 5;
    ctx.fillStyle = 'transparent';
    
    // Logo Box
    const logoX = 80;
    const logoY = 80;
    
    // Draw Wreath approximation (circles)
    ctx.beginPath();
    ctx.arc(logoX + 50, logoY + 50, 60, 0, Math.PI * 2);
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.fillStyle = 'white';
    ctx.font = `bold 30px ${FONT_VARSITY}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText("FIT", logoX + 50, logoY + 40);
    
    ctx.font = `16px ${FONT_ALERON}`;
    ctx.fillStyle = 'white';
    ctx.fillText("COLLEGE", logoX + 50, logoY + 70);
    ctx.restore();

    // SKILLS LOCKER Text
    ctx.save();
    ctx.font = `120px ${FONT_VARSITY}`;
    ctx.fillStyle = 'transparent'; // Outline only style from prompt description ("not outlined like it is in skills lockers"? Wait. Prompt says: "black text in middle is Varsity... giving appearance of uppercase but NOT outlined LIKE IT IS IN SKILLS LOCKERS". Implies Skills Locker IS outlined.)
    // So Skills Locker = Outlined.
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 4;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    const titleX = 300;
    const titleY = 70;
    ctx.strokeText("SKILLS LOCKER", titleX, titleY);
    // Double stroke for effect?
    ctx.lineWidth = 1;
    ctx.strokeText("SKILLS LOCKER", titleX, titleY);
    ctx.restore();

    // --- 3. Branch Label ---
    if (data.branch) {
      ctx.save();
      const branchText = data.branch; // Font handles casing, prompt says "lower case this gives it the appearance of uppercase". The Font 'Graduate' is uppercase-ish.
      ctx.font = `60px ${FONT_VARSITY}`;
      
      // Measure text for background box
      const metrics = ctx.measureText(branchText);
      const textWidth = metrics.width;
      const padding = 40;
      const boxHeight = 100;
      const boxWidth = textWidth + (padding * 2);
      const boxX = 100;
      const boxY = 320;

      // Draw rounded rect
      ctx.fillStyle = 'white';
      ctx.beginPath();
      ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 20);
      ctx.fill();

      // Draw Text
      ctx.fillStyle = 'black';
      ctx.textBaseline = 'middle';
      ctx.textAlign = 'left';
      // Prompt says: "Varsity but in the lower case... not outlined".
      // We will render it standard fill.
      ctx.fillText(branchText.toLowerCase(), boxX + padding, boxY + (boxHeight / 2) + 5);
      ctx.restore();
    }

    // --- 4. Course Name ---
    if (data.courseName) {
      ctx.save();
      const courseName = data.courseName.toUpperCase();
      let fontSize = 110;
      ctx.font = `bold ${fontSize}px ${FONT_ALERON}`;
      
      // Auto-scale text to fit width (max width approx 55% of screen)
      const maxTextWidth = CANVAS_WIDTH * 0.55; 
      let textMetrics = ctx.measureText(courseName);
      
      while (textMetrics.width > maxTextWidth && fontSize > 40) {
        fontSize -= 5;
        ctx.font = `bold ${fontSize}px ${FONT_ALERON}`;
        textMetrics = ctx.measureText(courseName);
      }

      // Wrapping logic if still too long or just want multi-line
      // For this prototype, we'll simple scale down or simple wrap.
      // Let's implement simple word wrap.
      const words = courseName.split(' ');
      let line = '';
      let y = 550;
      const lineHeight = fontSize * 1.2;

      for(let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxTextWidth && n > 0) {
          ctx.fillStyle = 'white';
          ctx.fillText(line, 100, y);
          line = words[n] + ' ';
          y += lineHeight;
        } else {
          line = testLine;
        }
      }
      ctx.fillStyle = 'white';
      ctx.fillText(line, 100, y);
      ctx.restore();
    }

    // --- 5. User Profile Image (Right Side) ---
    // Prioritize processed image, fallback to raw profile (with simple filter?)
    const imgToDraw = imagesLoaded.processed || imagesLoaded.profile;
    
    if (imgToDraw) {
      ctx.save();
      // Position: Right side, aligned bottom.
      // Scale logic: maintain aspect ratio, height approx 80% of canvas
      const targetHeight = CANVAS_HEIGHT * 0.9;
      const scale = targetHeight / imgToDraw.height;
      const drawWidth = imgToDraw.width * scale;
      const drawHeight = imgToDraw.height * scale;
      const drawX = CANVAS_WIDTH - drawWidth + 50; // Shift slightly right
      const drawY = CANVAS_HEIGHT - drawHeight;

      if (imagesLoaded.processed) {
        // AI Processed image handling
        // Create a temporary canvas to process transparency
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = drawWidth;
        tempCanvas.height = drawHeight;
        const tempCtx = tempCanvas.getContext('2d');
        if (tempCtx) {
           tempCtx.drawImage(imgToDraw, 0, 0, drawWidth, drawHeight);
           const imageData = tempCtx.getImageData(0, 0, drawWidth, drawHeight);
           const data = imageData.data;
           
           // Improved Chroma Key for Magenta (#FF00FF)
           // Assumptions:
           // 1. Subject is Grayscale (R~=G~=B) + White Outline (R=255,G=255,B=255)
           // 2. Background is Magenta (R=high, B=high, G=low)
           // 3. Edges/Halos will be pinkish (R=high, B=high, G=medium-low)
           //
           // Logic: If Red and Blue are significantly greater than Green, it's magenta/pink.
           // For grayscale/white, R, G, B are roughly equal.
           
           const threshold = 30; // Tolerance for "significantly greater"

           for(let i = 0; i < data.length; i += 4) {
             const r = data[i];
             const g = data[i + 1];
             const b = data[i + 2];
             
             // Check if pixel is magenta-dominated
             const rDiff = r - g;
             const bDiff = b - g;

             // If both Red and Blue channel exceed Green channel by threshold, key it out.
             if (rDiff > threshold && bDiff > threshold) {
               data[i + 3] = 0; // Alpha 0
             }
           }
           tempCtx.putImageData(imageData, 0, 0);
           ctx.drawImage(tempCanvas, drawX, drawY, drawWidth, drawHeight);
        }
      } else {
        // Raw Image Fallback (User hasn't clicked AI process)
        // Apply simple client-side grayscale + contrast
        // Note: Canvas filters like this only work if we assume background is transparent or user accepts box
        // We cannot easily remove background client side without library.
        // So we just draw it cut-out style if user uploaded transparent png.
        ctx.filter = 'grayscale(100%) contrast(150%)';
        // Stroke effect is hard on raw raster without edges.
        // We'll just draw the image.
        ctx.drawImage(imgToDraw, drawX, drawY, drawWidth, drawHeight);
        ctx.filter = 'none';
      }
      ctx.restore();
    }

    // --- 6. Footer ("With Full Name") ---
    if (data.fullName) {
      ctx.save();
      ctx.font = `60px ${FONT_DIAMOND}`;
      ctx.textBaseline = 'bottom';
      const startX = 250;
      const startY = CANVAS_HEIGHT - 80;

      // "With" (Black)
      ctx.fillStyle = 'black';
      ctx.fillText("With", startX, startY);
      
      const withWidth = ctx.measureText("With ").width;

      // "Full Name" (White)
      ctx.fillStyle = 'white';
      ctx.fillText(data.fullName, startX + withWidth + 10, startY);
      ctx.restore();
    }

    if (onCanvasReady) {
      onCanvasReady(canvas);
    }

  }, [data, imagesLoaded, onCanvasReady]);

  return (
    <div className="w-full aspect-video shadow-2xl rounded-lg overflow-hidden border border-gray-200 bg-gray-900">
      <canvas 
        ref={canvasRef} 
        width={CANVAS_WIDTH} 
        height={CANVAS_HEIGHT}
        className="w-full h-full object-contain"
      />
    </div>
  );
};

export default ThumbnailCanvas;